class Student:
    # [assignment] Skeleton class. Add your code here
    def __init__(self, name, age, tracks, score):
        self.name = name
        self.age = age
        self.tracks = tracks
        self.score = score



Bob = Student(name="Bob", age=26, tracks=["FE","BE"],score=20.90)
Peter = Student(name="Peter", age=34, tracks=["UI/UX"],score= 20.90)

# Expected methods
print(Peter.name)
print(Peter.age)
print(Peter.tracks)
print(Peter.score)


print(Bob.name)
print(Bob.age)
print(Bob.tracks)
print(Bob.score)
